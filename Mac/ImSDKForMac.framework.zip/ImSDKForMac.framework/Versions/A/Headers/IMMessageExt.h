//
//  IMMessageExt.h
//  IMMessageExt
//
//  Created by tomzhu on 2016/12/27.
//
//

#ifndef ImSDK_h
#define ImSDK_h

#import "ImSDK.h"
#import "TIMConversation+MsgExt.h"
#import "TIMMessage+MsgExt.h"
#import "TIMComm+MsgExt.h"
#import "TIMManager+MsgExt.h"

#endif /* ImSDK_h */
