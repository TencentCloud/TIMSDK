//
//  IMGroupExt.h
//  IMGroupExt
//
//  Created by tomzhu on 2017/1/23.
//
//

#ifndef IMGroupExt_h
#define IMGroupExt_h

#import "ImSDK.h"
#import "TIMComm+Group.h"
#import "TIMGroupManager+Ext.h"

#endif /* IMGroupExt_h */
