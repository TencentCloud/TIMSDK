//
//  TIMPush.h
//  TIMPush
//
//  Created by yiliangwang on 2024/8/7.
//  Copyright (c) 2024 Tencent. All rights reserved.
//

#ifndef TIMPush_h
#define TIMPush_h

#import "TIMPushManager.h"
#endif /* TIMPush_h */
